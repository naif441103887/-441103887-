<?php

$firstName = "";
$lastName = "";
$email = "";

$errors = [
    'firstNameErro' => '',
    'lastNameErro' => '',
    'emailErro' => '',
];

if(isset($_POST['submit']))
{
    $firstName = mysqli_real_escape_string($conn, $_POST['firstName']);
    $lastName = mysqli_real_escape_string($conn, $_POST['lastName']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    if(empty($firstName))
    {
        $errors['firstNameErro'] = "الرجاء أدخال الأسم الأول";
    }
    if(empty($lastName)) 
    {
        $errors['lastNameErro'] = "الرجاء أدخال الأسم الأخير";
    }
    if(empty($email))
    {
        $errors['emailErro'] = "الرجاء أدخال البريد الإلكتروني";
    }
    elseif(!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
        $errors['emailErro'] = "البريد الإلكتروني غير صحيح";
    }

    if(!array_filter($errors))
    {
        
        $sql = "INSERT INTO `users` (`firstName`, `lastName`, `email`) 
                VALUES ('$firstName', '$lastName', '$email')";

        if(mysqli_query($conn, $sql))
        {
            header("location:" . $_SERVER['PHP_SELF']);
        }
        else
        {
            echo "Error " . mysqli_error($conn);
        }
    }

    
}
