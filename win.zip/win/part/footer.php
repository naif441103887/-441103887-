<script src="./js/bootstrap.bundle.min.js"></script>
    <script src="./js/loader.js"></script>
    <script src="./js/script.js"></script>
</body>
</html>